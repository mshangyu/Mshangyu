public class zidong
{
	public static void main(String[] args) 
	{
		int a=10;
		double aa=1.201;
		double sum=a+aa;
		String A="��";
		char B='Ů';
		char C='��';
		String D=C+A+B;
		System.out.println("a="+a);
		System.out.println("aa="+aa);
		System.out.println("��Ϊ:"+(a+aa));
		System.out.println("sumΪ:"+sum);
		System.out.println(C+A+B);
		System.out.println(D);
	}
}
