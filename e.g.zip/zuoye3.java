public class zuoye3
{
	public static void main(String[] args) 
	{
		String A="���";
		String B="��Ҳ��";
		String temp=A;
		A=B;
		B=temp;
		System.out.println("AΪ��"+A);
		System.out.println("BΪ��"+B);
	}
}
