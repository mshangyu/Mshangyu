class score
{
	public static void main(String[] args) 
	{
		int aScore=80;
		int bScore;
		bScore=aScore;
		System.out.println(bScore);
	}
}
