import java.util.Scanner;
public class zuoye2  
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		System.out.println("����������һ��������");
		int inter=in.nextInt();
		System.out.println("1*"+inter+"="+(1*inter));
		System.out.println("2*"+inter+"="+(2*inter));
		System.out.println("3*"+inter+"="+(3*inter));
		System.out.println("4*"+inter+"="+(4*inter));
		System.out.println("5*"+inter+"="+(5*inter));
	}
}
