public class jiaohuan 
{
	public static void main(String[] args) 
	{
		int a=89;
		int b=10;
		int temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println(a);
		System.out.println(b);
	}
}
