public class guanxi 
{
	public static void main(String[] args) 
	{
		int A=2;
		int B=2;
		boolean comp;
		comp=A!=B;
		System.out.println(comp);
	}
}
